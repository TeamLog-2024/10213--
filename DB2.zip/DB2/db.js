const mysql = require('mysql');
const dotenv = require('dotenv');

dotenv.config();

const db = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '0817',
    database : 'userDB'
})

db.connect((err) => {
    if (err) console.log(err);
    console.log('Connected to MySQL database');
});

module.exports = db; 