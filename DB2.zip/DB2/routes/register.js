const express = require('express');
const db = require('../db');

const router = express.Router();

router.use(express.json());
router.use(express.urlencoded({ extended: false }));

router.get('/', (req, res) => {
    const message = req.session.message;
    req.session.message = null;
    res.render('register', { message });
});

router.post('/', (req, res) => {
    const { username, password } = req.body;
    db.query('SELECT COUNT(*) AS count FROM users WHERE username = ?', 
        [username], 
        (err, results,fields) => {
            console.log('select worked', results);
            console.log(fields);
            console.log(err);
            const count = results[0].count;

        if (count === 0) {
            db.query('INSERT INTO users (username, password) VALUES (?, ?)', 
                [username, password], 
            (err,results, password) => {
                console.log('insert worked:', results);
                console.log(fields);
                if(err) console.log(err);
                req.session.message = 'Register succeeded';
                res.redirect('/login');
            });
        } else {
            req.session.message = 'Register failed';
            res.redirect('/register');
        }
    }
    )
})

module.exports = router;
