const express = require('express');
const db = require('../db');

const router = express.Router();

router.use(express.json());
router.use(express.urlencoded({ extended: false }));

router.get('/', (req, res) => {
    const message = req.session.message;
    req.session.message = null; 
    res.render('login', {message});
});

router.post('/', (req, res) => {
    const { username, password} = req.body;

    db.query('SELECT * FROM info WHERE username = ? AND password = ?', 
        [username, password],
    (err, results) => {
        console.log('select worked:', results);
        console.log(fields);
        console.log(err);

        if (results.length > 0) {
            req.session.isLoggedIn = true;
            req.session.username = results[0].username;
            req.session.message = 'Logged in';
            res.redirect('/');
        } else {
            req.session.message = 'Login failed';
            res.redirect('/login');
        }
    });
});

module.exports = router;
