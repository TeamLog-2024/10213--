const express = require('express');
const session = require('express-session');
const registerRouter = require('./routes/register');
const loginRouter = require('./routes/login');

const app = express();
const PORT = 3000;

app.set('view engine', 'pug');
app.set('views', 'views');

app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: true
}));

app.use('/register', registerRouter);
app.use('/login', loginRouter);

app.get('/', (req, res) => {
    res.render('index', { username: req.session.username });
});

app.listen(PORT, (err) => {
    if (err) console.error(err);
    console.log(`Server open at ${PORT}`);
});
